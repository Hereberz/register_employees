#include "employee.h"
//#include "function.cpp"
#include "engineer.h"
#include "developer.h"

#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;
void loading();
int escolha();
void print();
void printDev();
void printEng();
void saving();
void loading(){
    ifstream myFile;
    int i=0;

    myFile.open("exempro.dat");
    
    for (auto it=empo.begin(); it != empo.end(); it++)
    {
 
        myFile<< empo[i]->type() <<endl;
        myFile<< empo[i]->getName() <<endl;
        myFile<< empo[i]->getSalary() <<endl;
        myFile<< empo[i]->getDate() <<endl;
        
       if(empo[i]->type()=="dev"){
            myFile<< empo[i]->getLanguage() <<endl;
        }
        else{
            myFile<< empo[i]->getFormation() <<endl;
        }
        i++;
    }
    myFile.close();
}
int escolha(const vector<Employee*> &employ){
    char select;
    cin>>select;
    switch (select)
    {
    case '1':
        loading();
        break;
    case '2':
        saving(employ);
        break;
    case '3':
        Employee *temp;                 //CRIAÇÃO DE FUNCIONARIOS
        temp = new Engineer();
        employ.push_back();
        break;
    case '4':
        print(employ);
        break;
    case '5':
        cout<<"Qual função deseja listar?\n1 - Engenheiro\n2 - Programador";
        char sel;
        while(sel!=1 || sel!=2)
        {
            cin>>sel;
        };
        if(sel==1)
        {
            printEng(employ);
        }
        else{
            printDev(employ);
        }
        print(employ);
        break;
    case '6':
        printBySalary(employ);
        break;
    case '7':
        return 1;
        break;
    default:
        cout<< "\nOpção inválida!\n";
        break;
    }
    return 0;
}
void print(const vector<Employee*> &empo)
{
    for(unsigned int i=0;i<empo.size();i++){
        empo[i]->print();
    //empo.at(i)->print();
    }
}
void printDev(const vector<Employee*> &empo)
{
    for(unsigned int i=0;i<empo.size();i++){
//      cout<<endl<<endl<<empo[i]->type()<<endl<<endl;
        if(empo[i]->type()=="dev")
        {
        empo[i]->print();
        }
    }
}
void printEng(const vector<Employee*> &empo)
{
    for(unsigned int i=0;i<empo.size();i++){
//        cout<<endl<<endl<<empo[i]->type()<<endl<<endl;
        if(empo[i]->type()=="eng")
        {
        empo[i]->print();
        }
    }
}
bool minhaFuncao    (Employee *emp1, Employee *emp2) {return (emp1->getSalary()<emp2->getSalary());}
bool minhaFuncao2   (Employee *emp1, Employee *emp2) {return (emp1->getSalary()>emp2->getSalary());}
void saving(const vector<Employee*> &empo){

    cout<< "Salvando..."<<endl;
    ofstream myFile;
    int i=0;
    myFile.open("exempro.dat");
    for (auto it=empo.begin(); it != empo.end(); it++)
    {
 
        myFile<< empo[i]->type() <<endl;
        myFile<< empo[i]->getName() <<endl;
        myFile<< empo[i]->getSalary() <<endl;
        myFile<< empo[i]->getDate() <<endl;
        
       if(empo[i]->type()=="dev"){
            myFile<< empo[i]->getLanguage() <<endl;
        }
        else{
            myFile<< empo[i]->getFormation() <<endl;
        }
        i++;
    }
    myFile.close();
}
void add(const vector<Employee*> &employ){
    Employee *temp;                 //CRIAÇÃO DE FUNCIONARIOS
    temp = new Engineer("biruta alucinado", 15.0, "05/05/03", "computação");
    employ.push_back(temp);
}
void menu(const vector<Employee*> &employ){
do {
cout<<"\n 1 - Carregar dados do arquivo";

cout<<"\n 2 - Salvar dados no arquivo";

cout<<"\n 3 - Adicionar funcionário (Engenheiro ou Programador)";

cout<<"\n 4 - Listar todos os funcionários";

cout<<"\n 5 - Listar funcionários por salário";

cout<<"\n 6 - Listar funcionários por função (Engenheiro ou Programador)";

cout<<"\n 7 - Listar funcionários por salário";

cout<<"\n 0 - Sair do programa";

cout<<"\n Enter selection: ";
}
while(escolha(employ)!=1);
}


void printBySalary(const vector<Employee*> &employ){
    vector<Employee*> tempo;
    for(int i=0; i<employ.size();i++)
    {
        tempo.push_back(employ[i]);
    }
    sort(tempo.begin(), tempo.end(), minhaFuncao);  
    print(tempo);
    tempo.clear();
}



int main()
{
    vector<Employee*> employ;
    menu(employ);
    Employee *temp;                 //CRIAÇÃO DE FUNCIONARIOS
    temp = new Engineer("biruta alucinado", 15.0, "05/05/03", "computação");
    employ.push_back(temp);
    temp = new Developer("batata voadora", 17.00, "07/05/2008", "ruby");
    employ.push_back(temp);
    temp = new Engineer("barco adoidado", 10.0, "05/05/2003", "civil");
    employ.push_back(temp);
    temp = new Developer("boliche ilusório", 75.00, "09/01/2008", "java");
    employ.push_back(temp);
    temp = new Engineer("barata assassina", 30.0, "05/05/2003", "prod");
    employ.push_back(temp);
    temp = new Developer("bocó alheio", 17.50, "02/03/2057", "C++");
    employ.push_back(temp);
    //print(employ);
    //cout << endl << endl << endl << endl;
    sort(employ.begin(), employ.end(), minhaFuncao);        //ordenação por salário
    print(employ);
    cout << endl << endl;
                                    //Exportar para arquivo

    saving(employ);
    /*
    ofstream myFile;
    myFile.open("exempro.dat");
    for (auto it=employ.begin(); it != employ.end(); it++)
    {
 
        myFile<< employ[i]->type() <<endl;
        myFile<< employ[i]->getName() <<endl;
        myFile<< employ[i]->getSalary() <<endl;
        myFile<< employ[i]->getDate() <<endl;
        
       if(employ[i]->type()=="dev"){
            myFile<< employ[i]->getLanguage() <<endl;
        }
        else{
            myFile<< employ[i]->getFormation() <<endl;
        }
        i++;
    }
    myFile.close();
    */
    return 0;
    
}